typedef struct termino
     {
     double lit;
     int exp;    
     }Termino;

typedef Termino item;
#include "ListaEnlazada.h"

void InsertarLista(NODO **cab, int *x)
{
     NODO *aux = (NODO *)malloc(sizeof(NODO));
     aux->dato = x;
     aux->siguiente = *cab;
     *cab = aux;
}
   void ImprimirLista(NODO *cab) 
 {
      system("cls");
      if(cab==NULL)
      {
      printf("La lista esta vacian");
      }
      else{
      printf("nel polinomio es:n");
      printf("n");
      while (cab != NULL) {
            printf( "%2.2f",cab->dato->lit);
            printf( "x^");
            printf( "%2.2f  +",cab->dato->exp);
            cab = cab->siguiente;
      }}
 }
 
void InsertarOrden(NODO **cab,item *valor)
    {                    
    NODO *nuevo,*back,*next;
    nuevo=(NODO *) malloc (sizeof(NODO));
    if(nuevo != NULL)
    {
       nuevo->dato=valor;
       nuevo->siguiente=NULL;
       back=NULL;
       next=(*cab);
       while(next != NULL && (valor->exp) < next->dato->exp)
          {
           back=next;
           next=next->siguiente;
          }
       if(back==NULL)
          {
           nuevo->siguiente=(*cab);
           (*cab)=nuevo;
          }
       else
       {
       back->siguiente=nuevo;
       nuevo->siguiente=next;
       }
    }
    else{printf("no hay espacio disponible en memoria");}
    } 
