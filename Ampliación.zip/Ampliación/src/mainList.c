#include <windows.h> 
#include <ListaEnlazada.c> 


void Sumarp(struct NODO *polmay,struct NODO *polmen);
void Restarp(struct NODO *polmay,struct NODO *polmen);
void Multp(struct NODO *cab,struct NODO *cab2);

main()
{
char opc;
int a,b;
struct NODO *cab,*cab2; 
char opc2;
cab=NULL;
cab2=NULL;
puts("Ingrese el polinomio numero 1");
a=polin(&cab);
puts("Ingrese el polinomio numero 2");
b=polin(&cab2); 

int polin(struct NODO **cab) //lee un polinomio
{
int cont=1;
char salir;
struct NODO nuevo,*aux;
aux=(*cab);
do{
   printf("Introduzca el coheficiente del %d termino : ",cont);
   nuevo.dato=(item *) malloc (sizeof(item));
   scanf("%f",&(nuevo.dato->lit));
   fflush(stdin);
   printf("Introduzca el exponente del %d termino : ",cont);
   scanf("%f",&(nuevo.dato->exp));
   fflush(stdin);
   InsertarOrden(&(*cab),nuevo.dato);
   ImprimirLista((*cab));
   puts("n desea introducir otro termino presiona "s"  para salir presiona "n"");
   salir=getchar();
   cont++;
  }while(salir!='n');
} 

void Sumarp(NODO *pol1,NODO *pol2)//suma un polinomio
   {
   int flag=0;
   NODO *suma=NULL,aux,*aux1;
   aux1=pol2;
   while(pol1 != NULL)
      {
      pol2=aux1;
      aux.dato=(item *) malloc (sizeof(item));
      while(pol2 != NULL)
         {
         if(pol1->dato->exp == pol2->dato->exp )
            {
            aux.dato->lit=pol1->dato->lit + pol2->dato->lit;
            aux.dato->exp=pol1->dato->exp;
            InsertarOrden(&suma,aux.dato);
            flag=1;
            }
            pol2=pol2->siguiente;
         }
         if(flag==0)
            {
            aux.dato->lit=pol1->dato->lit;
            aux.dato->exp=pol1->dato->exp;
            InsertarOrden(&suma,aux.dato);
            }
         pol1=pol1->siguiente;
         flag=0;
      }ImprimirLista(suma);printf("n");system("pause");
   }

void Restap(NODO *pol1,NODO *pol2)//resta un polinomio
   {
   int flag=0;
   NODO *resta=NULL,aux,*aux1;
   aux1=pol2;
   while(pol1 != NULL)
      {
      pol2=aux1;
      aux.dato=(item *) malloc (sizeof(item));
      while(pol2 != NULL)
         {
         if(pol1->dato->exp == pol2->dato->exp )
            {
            aux.dato->lit=pol1->dato->lit - pol2->dato->lit;
            aux.dato->exp=pol1->dato->exp;
            InsertarOrden(&resta,aux.dato);
            flag=1;
            }
            pol2=pol2->siguiente;
         }
         if(flag==0)
            {
            aux.dato->lit=pol1->dato->lit;
            aux.dato->exp=pol1->dato->exp;
            InsertarOrden(&resta,aux.dato);
            }
         pol1=pol1->siguiente;
         flag=0;
      }ImprimirLista(suma);printf("n");system("pause");
   }


void Multp(struct NODO *pol1,struct NODO *pol2)
{
int flag=0;
   struct NODO *mult=NULL,aux,*aux1;
   aux1=pol2;
   while(pol1 != NULL)
      {
      pol2=aux1;
      aux.dato=(item *) malloc (sizeof(item));
      while(pol2 != NULL)
         {
         
            aux.dato->lit=pol1->dato->lit * pol2->dato->lit;
            aux.dato->exp=pol1->dato->exp + pol2->dato->exp;
            InsertarOrden(&mult,aux.dato);
            flag=1;
            pol2=pol2->siguiente;
         }
         pol1=pol1->siguiente;
      }ImprimirLista(mult);printf("n");system("pause");
	  }
}

