 #include <stdio.h>
 #include <stdlib.h>

typedef struct Nodo {
        int *dato;
        struct Nodo *siguiente;
        }NODO;
 
 void InsertarLista(NODO **cab, int *x);
 void ImprimirLista(NODO *primero);
 void InsertarOrden(NODO **cab,int *valor) ;    
